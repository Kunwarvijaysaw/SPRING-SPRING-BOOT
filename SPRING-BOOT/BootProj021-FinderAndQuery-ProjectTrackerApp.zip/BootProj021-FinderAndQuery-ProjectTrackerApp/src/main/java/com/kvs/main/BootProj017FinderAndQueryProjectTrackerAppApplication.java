package com.kvs.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootProj017FinderAndQueryProjectTrackerAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootProj017FinderAndQueryProjectTrackerAppApplication.class, args);
	}

}
